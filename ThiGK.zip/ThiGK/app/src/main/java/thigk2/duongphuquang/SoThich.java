package thigk2.duongphuquang;

public class SoThich {
    String tvST;
    String imgST;

    public SoThich(String tvST, String imgST) {
        this.tvST = tvST;
        this.imgST = imgST;
    }

    public String getTvST() {
        return tvST;
    }

    public void setTvST(String tvST) {
        this.tvST = tvST;
    }

    public String getImgST() {
        return imgST;
    }

    public void setImgST(String imgST) {
        this.imgST = imgST;
    }
}
